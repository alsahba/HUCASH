package com.journaldev.barcodevisionapi.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.journaldev.barcodevisionapi.Model.RegisterResponse;
import com.journaldev.barcodevisionapi.R;
import com.journaldev.barcodevisionapi.RetrofitService.ApiClient;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EmailActivity extends AppCompatActivity implements View.OnClickListener {


    TextView txtRecipient;
    TextView txtAmount;
    TextView txtReceiver;
    Button btnConfirmPayment;
    String receiver, sender, amount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);
        initViews();
    }

    private void initViews() {

        txtRecipient = findViewById(R.id.txtRecipient);
        txtAmount = findViewById(R.id.txtAmount);
        txtReceiver = findViewById(R.id.txtReceiver);
        btnConfirmPayment = findViewById(R.id.btnConfirmPayment2);
        String paymentQrString = getIntent().getStringExtra("paymentDetails");
        String[] splittedPaymetQrString = paymentQrString.split("-");

        if (getIntent().getStringExtra("paymentDetails") != null) {
            sender = splittedPaymetQrString[0];
            amount = splittedPaymetQrString[1];
            receiver = splittedPaymetQrString[2];
            txtRecipient.setText("Recipient : " + sender);
            txtAmount.setText("Amount : " + amount);
            txtReceiver.setText("Receiver : " + receiver);
        }

        btnConfirmPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            /*Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{txtRecipient.getText().toString()});
            intent.putExtra(Intent.EXTRA_SUBJECT, inSubject.getText().toString().trim());
            intent.putExtra(Intent.EXTRA_TEXT, inBody.getText().toString().trim());
            startActivity(Intent.createChooser(intent, "Send Email"));*/
            register();

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btnScanBarcode:
                startActivity(new Intent(EmailActivity.this, ScannedBarcodeActivity.class));
                break;
        }

    }

    public void register(){
        HashMap<String, String> map = new HashMap<>();
        map.put("senderId", sender);
        map.put("receiverId", receiver);
        map.put("amount", amount);
        Call<RegisterResponse> call = ApiClient.getService().register(map);
        call.enqueue(new Callback<RegisterResponse>() {
            @Override
            public void onResponse(Call<RegisterResponse>call, Response<RegisterResponse> response) {
                RegisterResponse registerResponse = response.body();
                String message = registerResponse.getMessage();
                Log.d("Ret Register", "Service message is: " + message);
                Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<RegisterResponse>call, Throwable t) {
                Toast.makeText(getApplicationContext(),"An error occurred, please try again later.",Toast.LENGTH_SHORT).show();
                Log.e("Ret Register", t.toString());
            }
        });
    }

}
