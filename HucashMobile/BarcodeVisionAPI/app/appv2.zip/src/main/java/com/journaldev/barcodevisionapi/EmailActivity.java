package com.journaldev.barcodevisionapi;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class EmailActivity extends AppCompatActivity implements View.OnClickListener {

    EditText inSubject, inBody;
    TextView txtEmailAddress;
    TextView txtRecipient;
    TextView txtAmount;
    TextView txtReceiver;
    Button btnConfirmPayment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);
        initViews();
    }

    private void initViews() {

        txtRecipient = findViewById(R.id.txtRecipient);
        txtAmount = findViewById(R.id.txtAmount);
        txtReceiver = findViewById(R.id.txtReceiver);
        btnConfirmPayment = findViewById(R.id.btnConfirmPayment2);
        String paymentQrString = getIntent().getStringExtra("paymentDetails");
        String[] splittedPaymetQrString = paymentQrString.split("-");

        if (getIntent().getStringExtra("paymentDetails") != null) {
            txtRecipient.setText("Recipient : " + splittedPaymetQrString[0]);
            txtAmount.setText("Amount : " + splittedPaymetQrString[1]);
            txtReceiver.setText("Receiver : " + splittedPaymetQrString[2]);
        }

        btnConfirmPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
          /*      Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{txtRecipient.getText().toString()});
                intent.putExtra(Intent.EXTRA_SUBJECT, inSubject.getText().toString().trim());
                intent.putExtra(Intent.EXTRA_TEXT, inBody.getText().toString().trim());

                startActivity(Intent.createChooser(intent, "Send Email"));
                */
                httpPostRequest();

            }
        });
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.btnScanBarcode:
                startActivity(new Intent(EmailActivity.this, ScannedBarcodeActivity.class));
                break;
        }

    }

    public static String httpPostRequest() {
// Create a new HttpClient and Post Header
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost("http://46.101.212.47:8000/register");

        try {
            // Add your data
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
            nameValuePairs.add(new BasicNameValuePair("username", "alikasari"));
            nameValuePairs.add(new BasicNameValuePair("password", "benKasarim12"));
            nameValuePairs.add(new BasicNameValuePair("firstName", "ali"));
            nameValuePairs.add(new BasicNameValuePair("lastName", "balik"));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

            // Execute HTTP Post Request
            HttpResponse response = httpclient.execute(httppost);

        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
        } catch (IOException e) {
            // TODO Auto-generated catch block
        }
    return  null;
    }
}
